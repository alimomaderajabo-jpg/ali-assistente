'use strict';
/*
  Uso (no servidor, por terminal):
    node scripts/make-admin.js <username>            dá a função de administrador
    node scripts/make-admin.js <username> --remover  retira a função
  Não existe forma de fazer isto pela internet nem pela aplicação.
*/
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const [, , username, flag] = process.argv;
if (!username) {
  console.error('Uso: node scripts/make-admin.js <username> [--remover]');
  process.exit(1);
}
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const db = new DatabaseSync(path.join(DATA_DIR, 'ali.db'));
const user = db.prepare('SELECT id, username, role FROM users WHERE username = ?').get(username.toLowerCase());
if (!user) {
  console.error('Conta não encontrada: ' + username);
  process.exit(1);
}
const role = flag === '--remover' ? 'user' : 'admin';
db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, user.id);
console.log(`Conta ${user.username} agora tem a função: ${role}`);
