'use strict';
// Imita o endpoint streamGenerateContent do Gemini (SSE). Só para testes locais.
const http = require('node:http');

const seen = [];
const server = http.createServer((req, res) => {
  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    seen.push({ url: req.url, key: req.headers['x-goog-api-key'], body: JSON.parse(body || '{}') });
    if (req.url.includes('fail-test')) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: { message: 'modelo inválido de teste' } }));
    }
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    res.write('data: ' + JSON.stringify({ candidates: [{ content: { parts: [{ text: 'Olá ' }] } }] }) + '\n\n');
    res.write('data: ' + JSON.stringify({ candidates: [{ content: { parts: [{ text: 'do mock' }] } }] }) + '\n\n');
    res.end();
  });
});
server.seen = seen;
module.exports = server;

if (require.main === module) {
  server.listen(4555, () => console.log('mock gemini em 4555'));
}
