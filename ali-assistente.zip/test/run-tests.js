'use strict';
const { spawn, execFileSync } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const mock = require('./mock-gemini');

const ROOT = path.join(__dirname, '..');
const DATA = path.join(ROOT, 'test-data-' + Date.now());
const PORT = 3100, MOCK = 4555, KEY = 'CHAVE-TESTE-123-SECRETA';
const BASE = `http://localhost:${PORT}`;
const results = [];
let serverProc;

function startServer(){
  return new Promise((resolve, reject) => {
    serverProc = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: {
      ...process.env, PORT: String(PORT), DATA_DIR: DATA, GEMINI_API_KEY: KEY,
      GEMINI_BASE_URL: `http://localhost:${MOCK}`, DAILY_LIMIT: '5', GEMINI_MODEL: 'gemini-2.5-flash' }, stdio: ['ignore','pipe','pipe'] });
    let out = '';
    serverProc.stdout.on('data', d => { out += d; if (out.includes('a correr')) resolve(); });
    serverProc.stderr.on('data', d => { out += d; });
    serverProc.on('exit', c => { if (!out.includes('a correr')) reject(new Error('servidor não arrancou: ' + out)); });
    setTimeout(() => reject(new Error('timeout ao arrancar: ' + out)), 8000);
  });
}
const stopServer = () => new Promise(r => { if (!serverProc) return r(); serverProc.on('exit', r); serverProc.kill(); });

async function req(method, p, { cookie, body, headers = {} } = {}){
  const h = { ...headers };
  if (cookie) h.cookie = `ali_session=${cookie}`;
  let payload;
  if (body !== undefined){ h['content-type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(BASE + p, { method, headers: h, body: payload, redirect: 'manual' });
  const text = await r.text();
  let json = null; try { json = JSON.parse(text); } catch {}
  const sc = r.headers.get('set-cookie') || '';
  const m = sc.match(/ali_session=([^;]*)/);
  return { status: r.status, json, text, cookie: m ? m[1] : null, setCookie: sc };
}
async function test(name, fn){
  try { await fn(); results.push(['OK', name]); }
  catch (e){ results.push(['FALHOU', name + ' -> ' + e.message.split('\n')[0]]); }
}

(async () => {
  const mockSrv = mock.listen(MOCK);
  await new Promise(r => mockSrv.once('listening', r));
  await startServer();
  let alice, bob, admin;

  await test('registar conta nova devolve 201 e cookie HttpOnly', async () => {
    const r = await req('POST', '/api/auth/register', { body: { username: 'alice', email: 'alice@exemplo.pt', password: 'segredo123' } });
    assert.equal(r.status, 201); assert.ok(r.cookie); assert.match(r.setCookie, /HttpOnly/); assert.match(r.setCookie, /SameSite=Lax/);
    assert.equal(r.json.user.username, 'alice'); assert.equal(r.json.user.role, 'user');
    alice = r.cookie;
  });
  await test('não cria o mesmo nome de utilizador outra vez (409)', async () => {
    const r = await req('POST', '/api/auth/register', { body: { username: 'ALICE', email: 'outra@exemplo.pt', password: 'segredo123' } });
    assert.equal(r.status, 409); assert.match(r.json.error.message, /nome de utilizador já existe/);
  });
  await test('não cria a mesma conta com email repetido (409)', async () => {
    const r = await req('POST', '/api/auth/register', { body: { username: 'alice2', email: 'ALICE@exemplo.pt', password: 'segredo123' } });
    assert.equal(r.status, 409); assert.match(r.json.error.message, /email/);
  });
  await test('valida palavra-passe curta e nome inválido com mensagem em português', async () => {
    let r = await req('POST', '/api/auth/register', { body: { username: 'bob', email: 'bob@exemplo.pt', password: '123' } });
    assert.equal(r.status, 400); assert.match(r.json.error.message, /8 caracteres/);
    r = await req('POST', '/api/auth/register', { body: { username: 'b o', email: 'bob@exemplo.pt', password: 'segredo123' } });
    assert.equal(r.status, 400); assert.match(r.json.error.message, /nome de utilizador/);
  });
  await test('palavra-passe nunca fica em texto simples na base de dados', async () => {
    const { DatabaseSync } = require('node:sqlite');
    const d = new DatabaseSync(path.join(DATA, 'ali.db'));
    const row = d.prepare("SELECT password_hash FROM users WHERE username='alice'").get();
    assert.ok(row.password_hash.startsWith('scrypt$')); assert.ok(!row.password_hash.includes('segredo123'));
    d.close();
  });
  await test('login com palavra-passe errada devolve 401', async () => {
    const r = await req('POST', '/api/auth/login', { body: { identifier: 'alice', password: 'errada99' } });
    assert.equal(r.status, 401);
  });
  await test('login com a mesma conta funciona (por nome e por email)', async () => {
    let r = await req('POST', '/api/auth/login', { body: { identifier: 'alice', password: 'segredo123' } });
    assert.equal(r.status, 200); assert.ok(r.cookie);
    r = await req('POST', '/api/auth/login', { body: { identifier: 'alice@exemplo.pt', password: 'segredo123' } });
    assert.equal(r.status, 200);
    alice = r.cookie;
  });
  await test('/api/auth/me sem sessão dá 401 e com sessão dá o utilizador', async () => {
    assert.equal((await req('GET', '/api/auth/me')).status, 401);
    const r = await req('GET', '/api/auth/me', { cookie: alice }); assert.equal(r.status, 200); assert.equal(r.json.user.username, 'alice');
  });
  await test('cookie falsificada não dá acesso', async () => {
    const r = await req('GET', '/api/state', { cookie: 'token-inventado-' + 'x'.repeat(20) }); assert.equal(r.status, 401);
  });
  await test('cada conta tem as suas próprias conversas (isolamento no servidor)', async () => {
    const st = { v: 4, current: 'c1', chats: [{ id:'c1', title:'Segredo da Alice', messages:[{role:'user',text:'olá'}] }], settings: { school:true, gkey:'NAO-DEVE-FICAR', mem:['gosto de física'] } };
    let r = await req('PUT', '/api/state', { cookie: alice, body: { state: st } }); assert.equal(r.status, 200);
    r = await req('POST', '/api/auth/register', { body: { username: 'bob', email: 'bob@exemplo.pt', password: 'bobpass99' } }); assert.equal(r.status, 201); bob = r.cookie;
    r = await req('GET', '/api/state', { cookie: bob }); assert.equal(r.status, 200); assert.equal(r.json.state, null);
    r = await req('GET', '/api/state', { cookie: alice }); assert.equal(r.json.state.chats[0].title, 'Segredo da Alice');
  });
  await test('chave Gemini guardada nas definições nunca fica no servidor', async () => {
    const r = await req('GET', '/api/state', { cookie: alice });
    assert.ok(!JSON.stringify(r.json).includes('NAO-DEVE-FICAR'));
    assert.equal(r.json.state.settings.mem[0], 'gosto de física');
  });
  await test('o utilizador comum não consegue aceder ao painel administrativo (403)', async () => {
    assert.equal((await req('GET', '/api/admin/users', { cookie: alice })).status, 403);
    assert.equal((await req('GET', '/api/admin/users')).status, 401);
    assert.equal((await req('POST', '/api/admin/users/2/disabled', { cookie: alice, body: { disabled: true } })).status, 403);
  });
  await test('IA sem sessão dá 401 e nunca chega ao Gemini', async () => {
    const before = mock.seen.length;
    const r = await req('POST', '/api/gemini/stream', { body: { model:'gemini-2.5-flash', request:{ contents:[{role:'user',parts:[{text:'x'}]}] } } });
    assert.equal(r.status, 401); assert.equal(mock.seen.length, before);
  });
  await test('IA com sessão faz stream da resposta e usa a chave só no servidor', async () => {
    const r = await req('POST', '/api/gemini/stream', { cookie: alice, body: { model:'gemini-2.5-flash', request:{ systemInstruction:{parts:[{text:'sys'}]}, contents:[{role:'user',parts:[{text:'oi'}]}], generationConfig:{maxOutputTokens: 999999}, tools:[{google_search:{}}], injetado:'lixo' } } });
    assert.equal(r.status, 200); assert.match(r.text, /Olá/); assert.match(r.text, /do mock/);
    const last = mock.seen[mock.seen.length-1];
    assert.equal(last.key, KEY);
    assert.ok(!last.body.injetado); assert.ok(last.body.tools[0].google_search);
    assert.ok(last.body.generationConfig.maxOutputTokens <= 8192);
  });
  await test('modelo com nome estranho cai para o modelo por defeito (sem injeção no URL)', async () => {
    await req('POST', '/api/gemini/stream', { cookie: alice, body: { model:'../../x?y', request:{ contents:[{role:'user',parts:[{text:'oi'}]}] } } });
    assert.match(mock.seen[mock.seen.length-1].url, /models\/gemini-2\.5-flash:/);
  });
  await test('erro 400 do Gemini chega à app com a mensagem (para o mecanismo de retry funcionar)', async () => {
    const r = await req('POST', '/api/gemini/stream', { cookie: alice, body: { model:'gemini-fail-test', request:{ contents:[{role:'user',parts:[{text:'oi'}]}] } } });
    assert.equal(r.status, 400); assert.match(r.json.error.message, /teste/);
    assert.ok(!r.text.includes(KEY));
  });
  await test('limite diário por conta: ao atingir o máximo dá 429, a outra conta não é afetada', async () => {
    // alice já tem 3 chamadas contadas (incluindo a que deu erro 400); o limite de teste é 5
    let oks = 0, last;
    for (let i = 0; i < 4; i++) {
      last = await req('POST', '/api/gemini/stream', { cookie: alice, body: { model:'gemini-2.5-flash', request:{ contents:[{role:'user',parts:[{text:'a'+i}]}] } } });
      if (last.status === 200) oks++;
    }
    assert.equal(oks, 2); assert.equal(last.status, 429); assert.match(last.json.error.message, /limite/);
    const r = await req('POST', '/api/gemini/stream', { cookie: bob, body: { model:'gemini-2.5-flash', request:{ contents:[{role:'user',parts:[{text:'c'}]}] } } });
    assert.equal(r.status, 200);
  });
  await test('pedido de outro site (Origin diferente) é bloqueado', async () => {
    const r = await req('POST', '/api/auth/logout', { cookie: alice, headers: { origin: 'https://site-mau.exemplo' } });
    assert.equal(r.status, 403);
  });
  await test('tentativas de login falhadas são limitadas (429 depois de 5)', async () => {
    let last;
    for (let i = 0; i < 6; i++) last = await req('POST', '/api/auth/login', { body: { identifier: 'bob', password: 'mauuu123' } });
    assert.equal(last.status, 429);
    const ok = await req('POST', '/api/auth/login', { body: { identifier: 'alice', password: 'segredo123' } });
    assert.equal(ok.status, 200);
  });
  await test('terminar sessão invalida o cookie', async () => {
    const t = await req('POST', '/api/auth/login', { body: { identifier: 'alice', password: 'segredo123' } });
    const out = await req('POST', '/api/auth/logout', { cookie: t.cookie });
    assert.equal(out.status, 200);
    assert.equal((await req('GET', '/api/auth/me', { cookie: t.cookie })).status, 401);
    alice = (await req('POST', '/api/auth/login', { body: { identifier: 'alice', password: 'segredo123' } })).cookie;
  });
  await test('apagar os dados e apagar a conta (com palavra-passe)', async () => {
    let r = await req('DELETE', '/api/state', { cookie: bob }); assert.equal(r.status, 200);
    r = await req('GET', '/api/state', { cookie: bob }); assert.equal(r.json.state, null);
    r = await req('POST', '/api/account/delete', { cookie: bob, body: { password: 'errada' } }); assert.equal(r.status, 401);
    r = await req('POST', '/api/account/delete', { cookie: bob, body: { password: 'bobpass99' } }); assert.equal(r.status, 200);
    assert.equal((await req('GET', '/api/auth/me', { cookie: bob })).status, 401);
  });
  await test('caminhos de ficheiros fora da pasta public não são servidos', async () => {
    const r = await req('GET', '/%2e%2e/server.js'); assert.notEqual(r.status, 200);
    const r2 = await req('GET', '/..%2f..%2fetc%2fpasswd'); assert.notEqual(r2.status, 200);
  });

  // criar admin só pelo script no servidor
  await test('administrador só existe depois do script no servidor', async () => {
    const ad = await req('POST', '/api/auth/register', { body: { username: 'chefe', email: 'chefe@exemplo.pt', password: 'chefe12345' } });
    assert.equal((await req('GET', '/api/admin/users', { cookie: ad.cookie })).status, 403);
    execFileSync(process.execPath, ['scripts/make-admin.js', 'chefe'], { cwd: ROOT, env: { ...process.env, DATA_DIR: DATA } });
    const login = await req('POST', '/api/auth/login', { body: { identifier: 'chefe', password: 'chefe12345' } });
    admin = login.cookie;
    const list = await req('GET', '/api/admin/users', { cookie: admin });
    assert.equal(list.status, 200);
    assert.ok(list.json.users.length >= 2);
    assert.ok(!list.text.includes('password_hash') && !list.text.includes('scrypt$'), 'não pode expor hashes');
    assert.ok(!list.text.includes(KEY));
  });
  await test('admin desativa utilizador: sessão cai e login é recusado', async () => {
    const list = await req('GET', '/api/admin/users', { cookie: admin });
    const alicId = list.json.users.find(u => u.username === 'alice').id;
    const chefeId = list.json.users.find(u => u.username === 'chefe').id;
    assert.equal((await req('POST', `/api/admin/users/${chefeId}/disabled`, { cookie: admin, body: { disabled: true } })).status, 400);
    assert.equal((await req('POST', `/api/admin/users/${alicId}/disabled`, { cookie: admin, body: { disabled: true } })).status, 200);
    assert.equal((await req('GET', '/api/auth/me', { cookie: alice })).status, 401);
    const l = await req('POST', '/api/auth/login', { body: { identifier: 'alice', password: 'segredo123' } });
    assert.equal(l.status, 403);
    await req('POST', `/api/admin/users/${alicId}/disabled`, { cookie: admin, body: { disabled: false } });
    alice = (await req('POST', '/api/auth/login', { body: { identifier: 'alice', password: 'segredo123' } })).cookie;
  });

  // persistência: reiniciar o servidor e voltar a entrar
  await test('dados e sessões sobrevivem a reiniciar o servidor', async () => {
    await stopServer(); await startServer();
    const r = await req('GET', '/api/state', { cookie: alice });
    assert.equal(r.status, 200); assert.equal(r.json.state.chats[0].title, 'Segredo da Alice');
    const me = await req('GET', '/api/auth/me', { cookie: alice }); assert.equal(me.status, 200);
  });

  await stopServer(); mockSrv.close();
  fs.rmSync(DATA, { recursive: true, force: true });
  for (const [s, n] of results) console.log(s.padEnd(7), n);
  const failed = results.filter(r => r[0] !== 'OK').length;
  console.log(`\n${results.length - failed}/${results.length} testes passaram`);
  process.exit(failed ? 1 : 0);
})().catch(async e => { console.error('ERRO NOS TESTES:', e); await stopServer(); process.exit(1); });
