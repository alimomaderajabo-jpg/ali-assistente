'use strict';
/*
  Ali Assistente — servidor (sem dependências externas, Node 22+).
  Variáveis de ambiente:
    GEMINI_API_KEY   (obrigatória para a IA) chave do Google AI Studio — NUNCA no código
    GEMINI_MODEL     modelo por defeito (confirma o nome atual no Google AI Studio)
    DAILY_LIMIT      pedidos à IA por conta e por dia (defeito 200)
    DATA_DIR         pasta da base de dados (defeito ./data)
    PORT             porta (defeito 3000)
    COOKIE_SECURE=1  ativar em produção com HTTPS (Render usa HTTPS)
*/
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const GEMINI_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_BASE = (process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com').replace(/\/$/, '');
const DEFAULT_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const DAILY_LIMIT = Number(process.env.DAILY_LIMIT) || 200;
const COOKIE_SECURE = process.env.COOKIE_SECURE === '1';
const SESSION_DAYS = 30;
const MAX_STATE_BYTES = 10 * 1024 * 1024;
const MAX_JSON_BYTES = 1024 * 1024;
const MAX_GEMINI_BYTES = 25 * 1024 * 1024;
const MAX_OUTPUT_TOKENS = 8192;
const LOGIN_MAX_FAILS = 5;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

/* ---------- base de dados ---------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'ali.db'));
db.exec(`
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  disabled INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user_state (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  state TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS usage (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);
CREATE TABLE IF NOT EXISTS admin_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  target_id INTEGER,
  detail TEXT,
  created_at TEXT NOT NULL
);
`);

/* ---------- utilitários ---------- */
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const httpErr = (status, message) => new HttpError(status, message);
const now = () => Date.now();
const today = () => new Date().toISOString().slice(0, 10);
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function sendError(res, status, message) {
  send(res, status, { error: { message } });
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0; let tooBig = false;
    req.on('data', c => {
      if (tooBig) return;
      size += c.length;
      if (size > limit) { tooBig = true; reject(httpErr(413, 'Pedido demasiado grande.')); return; }
      chunks.push(c);
    });
    req.on('end', () => { if (!tooBig) resolve(Buffer.concat(chunks)); });
    req.on('error', reject);
  });
}
async function readJson(req, limit = MAX_JSON_BYTES) {
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (type !== 'application/json') throw httpErr(415, 'Envia os dados em formato JSON.');
  const buf = await readBody(req, limit);
  if (!buf.length) return {};
  try { return JSON.parse(buf.toString('utf8')); }
  catch { throw httpErr(400, 'Pedido inválido (JSON mal formado).'); }
}

function parseCookies(h) {
  const out = {};
  String(h || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = p.slice(i + 1).trim();
  });
  return out;
}
function setSessionCookie(res, token, maxAgeSec) {
  const parts = [`ali_session=${token}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${maxAgeSec}`];
  if (COOKIE_SECURE) parts.push('Secure');
  res.setHeader('Set-Cookie', parts.join('; '));
}
function clientIp(req) {
  const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return xff || req.socket.remoteAddress || 'desconhecido';
}

/* Pedidos que alteram dados: se o navegador disser de que site vem, tem de ser este. */
function checkOrigin(req) {
  if (req.method === 'GET' || req.method === 'HEAD') return;
  const origin = req.headers.origin;
  if (!origin) return;
  let host = '';
  try { host = new URL(origin).host; } catch { host = ''; }
  if (host !== req.headers.host) throw httpErr(403, 'Pedido bloqueado por segurança.');
}

/* ---------- palavras-passe (scrypt, sal aleatório por conta) ---------- */
const SCRYPT_OPTS = { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(pw, salt, 64, SCRYPT_OPTS);
  return ['scrypt', SCRYPT_OPTS.N, SCRYPT_OPTS.r, SCRYPT_OPTS.p, salt.toString('base64'), hash.toString('base64')].join('$');
}
function verifyPassword(pw, stored) {
  const parts = String(stored).split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const expected = Buffer.from(parts[5], 'base64');
  const actual = crypto.scryptSync(pw, Buffer.from(parts[4], 'base64'), expected.length,
    { N: Number(parts[1]), r: Number(parts[2]), p: Number(parts[3]), maxmem: SCRYPT_OPTS.maxmem });
  return crypto.timingSafeEqual(actual, expected);
}
const DUMMY_HASH = hashPassword('palavra-passe-falsa-para-tempo-constante');

/* ---------- validação ---------- */
const USER_RE = /^[a-z0-9_]{3,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function validateRegister(body) {
  const u = String(body.username || '').trim().toLowerCase();
  const e = String(body.email || '').trim().toLowerCase();
  const p = String(body.password || '');
  if (!USER_RE.test(u)) return { error: 'O nome de utilizador tem de ter 3 a 20 letras minúsculas, números ou _ (sem espaços).' };
  if (e.length > 254 || !EMAIL_RE.test(e)) return { error: 'Escreve um endereço de email válido.' };
  if (p.length < 8) return { error: 'A palavra-passe tem de ter pelo menos 8 caracteres.' };
  if (p.length > 200) return { error: 'A palavra-passe é demasiado longa (máximo 200 caracteres).' };
  return { u, e, p };
}
const publicUser = r => ({ id: r.id, username: r.username, email: r.email, role: r.role });

/* ---------- limite de tentativas de login ---------- */
const failures = new Map();
function loginBlocked(key) {
  const f = failures.get(key);
  return !!f && f.until > now() && f.count >= LOGIN_MAX_FAILS;
}
function noteFailure(key) {
  let f = failures.get(key);
  if (!f || f.until <= now()) f = { count: 0, until: now() + LOGIN_WINDOW_MS };
  f.count++;
  failures.set(key, f);
}

/* ---------- sessões ---------- */
function createSession(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const t = now();
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(t);
  db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?,?,?,?)')
    .run(sha256(token), userId, t, t + SESSION_DAYS * 86400000);
  return token;
}
function currentUser(req) {
  const token = parseCookies(req.headers.cookie).ali_session;
  if (!token || token.length > 200) return null;
  const th = sha256(token);
  const row = db.prepare(`SELECT u.id, u.username, u.email, u.role, u.disabled, s.expires_at
                          FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`).get(th);
  if (!row) return null;
  if (row.expires_at < now()) { db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(th); return null; }
  if (row.disabled) return null;
  return row;
}
function requireUser(req) {
  const u = currentUser(req);
  if (!u) throw httpErr(401, 'Sessão inválida ou expirada. Entra outra vez.');
  return u;
}
/* A função admin só existe na base de dados e só é dada pelo script scripts/make-admin.js no servidor. */
function requireAdmin(req) {
  const u = requireUser(req);
  if (u.role !== 'admin') throw httpErr(403, 'Não tens permissão para esta operação.');
  return u;
}
function audit(adminId, action, targetId, detail) {
  db.prepare('INSERT INTO admin_log (admin_id, action, target_id, detail, created_at) VALUES (?,?,?,?,?)')
    .run(adminId, action, targetId ?? null, detail ?? null, new Date().toISOString());
}

/* ---------- contas ---------- */
async function register(req, res) {
  const body = await readJson(req);
  const v = validateRegister(body);
  if (v.error) throw httpErr(400, v.error);
  const dup = db.prepare('SELECT username, email FROM users WHERE username = ? OR email = ?').get(v.u, v.e);
  if (dup) {
    throw httpErr(409, String(dup.username).toLowerCase() === v.u
      ? 'Esse nome de utilizador já existe. Escolhe outro ou entra na conta.'
      : 'Já existe uma conta com esse email. Entra na conta.');
  }
  let id;
  try {
    const info = db.prepare('INSERT INTO users (username, email, password_hash, role, created_at) VALUES (?,?,?,?,?)')
      .run(v.u, v.e, hashPassword(v.p), 'user', new Date().toISOString());
    id = Number(info.lastInsertRowid);
  } catch (err) {
    if (/UNIQUE/i.test(String(err.message))) throw httpErr(409, 'Esse nome ou email já está registado.');
    throw err;
  }
  const token = createSession(id);
  setSessionCookie(res, token, SESSION_DAYS * 86400);
  send(res, 201, { user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id)) });
}

async function login(req, res) {
  const body = await readJson(req);
  const ident = String(body.identifier || '').trim().toLowerCase();
  const pw = String(body.password || '');
  if (!ident || !pw) throw httpErr(400, 'Escreve o nome (ou email) e a palavra-passe.');
  const key = clientIp(req) + ':' + ident;
  if (loginBlocked(key)) throw httpErr(429, 'Muitas tentativas falhadas. Espera 15 minutos e tenta outra vez.');
  const user = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get(ident, ident);
  let ok;
  if (user) ok = verifyPassword(pw, user.password_hash);
  else { verifyPassword(pw, DUMMY_HASH); ok = false; }
  if (!ok) { noteFailure(key); throw httpErr(401, 'Nome/email ou palavra-passe errados.'); }
  if (user.disabled) throw httpErr(403, 'Esta conta está desativada. Fala com o administrador.');
  failures.delete(key);
  const token = createSession(user.id);
  setSessionCookie(res, token, SESSION_DAYS * 86400);
  send(res, 200, { user: publicUser(user) });
}

function logout(req, res) {
  const token = parseCookies(req.headers.cookie).ali_session;
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
  setSessionCookie(res, '', 0);
  send(res, 200, { ok: true });
}

async function deleteAccount(req, res) {
  const u = requireUser(req);
  const body = await readJson(req);
  const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(u.id);
  if (!row || !verifyPassword(String(body.password || ''), row.password_hash)) {
    throw httpErr(401, 'Palavra-passe errada. A conta não foi apagada.');
  }
  db.prepare('DELETE FROM users WHERE id = ?').run(u.id);
  setSessionCookie(res, '', 0);
  send(res, 200, { ok: true });
}

/* ---------- dados do utilizador (estado: conversas, memória, preferências) ---------- */
function sanitizeState(s) {
  const settings = (s.settings && typeof s.settings === 'object' && !Array.isArray(s.settings)) ? { ...s.settings } : {};
  delete settings.gkey; // a chave do Gemini nunca é guardada no navegador nem na base de dados
  delete settings.key;
  return {
    v: Number(s.v) || 4,
    chats: Array.isArray(s.chats) ? s.chats : [],
    current: typeof s.current === 'string' ? s.current : null,
    settings
  };
}
function getState(req, res) {
  const u = requireUser(req);
  const row = db.prepare('SELECT state, updated_at FROM user_state WHERE user_id = ?').get(u.id);
  send(res, 200, { state: row ? JSON.parse(row.state) : null, updatedAt: row ? row.updated_at : null });
}
async function putState(req, res) {
  const u = requireUser(req);
  const body = await readJson(req, MAX_STATE_BYTES);
  if (!body.state || typeof body.state !== 'object' || Array.isArray(body.state)) throw httpErr(400, 'Dados inválidos.');
  const json = JSON.stringify(sanitizeState(body.state));
  const t = now();
  db.prepare(`INSERT INTO user_state (user_id, state, updated_at) VALUES (?,?,?)
              ON CONFLICT(user_id) DO UPDATE SET state = excluded.state, updated_at = excluded.updated_at`)
    .run(u.id, json, t);
  send(res, 200, { ok: true, updatedAt: t });
}
function deleteState(req, res) {
  const u = requireUser(req);
  db.prepare('DELETE FROM user_state WHERE user_id = ?').run(u.id);
  send(res, 200, { ok: true });
}

/* ---------- proxy para o Gemini ---------- */
function capGenerationConfig(gc) {
  const g = (gc && typeof gc === 'object') ? { ...gc } : {};
  g.maxOutputTokens = Math.min(Number(g.maxOutputTokens) || MAX_OUTPUT_TOKENS, MAX_OUTPUT_TOKENS);
  return g;
}
async function geminiStream(req, res) {
  const u = requireUser(req);
  if (!GEMINI_KEY) throw httpErr(503, 'O servidor ainda não tem a chave do Gemini configurada. Avisa o administrador.');
  const body = await readJson(req, MAX_GEMINI_BYTES);
  const model = (typeof body.model === 'string' && /^gemini-[a-z0-9.\-]{1,60}$/i.test(body.model.trim()))
    ? body.model.trim() : DEFAULT_MODEL;
  const request = body.request;
  if (!request || typeof request !== 'object' || !Array.isArray(request.contents) || !request.contents.length) {
    throw httpErr(400, 'Pedido inválido: falta a conversa.');
  }

  // limite diário por conta
  const used = db.prepare('SELECT count FROM usage WHERE user_id = ? AND day = ?').get(u.id, today());
  if (used && used.count >= DAILY_LIMIT) {
    throw httpErr(429, `Atingiste o limite de ${DAILY_LIMIT} pedidos por dia. Tenta amanhã.`);
  }
  db.prepare(`INSERT INTO usage (user_id, day, count) VALUES (?,?,1)
              ON CONFLICT(user_id, day) DO UPDATE SET count = count + 1`).run(u.id, today());

  // só se reencaminham os campos permitidos
  const upstreamBody = {
    contents: request.contents,
    generationConfig: capGenerationConfig(request.generationConfig)
  };
  if (request.systemInstruction) upstreamBody.systemInstruction = request.systemInstruction;
  if (Array.isArray(request.tools) && request.tools.some(t => t && t.google_search)) {
    upstreamBody.tools = [{ google_search: {} }];
  }

  const url = `${GEMINI_BASE}/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
  const ctl = new AbortController();
  const tmo = setTimeout(() => ctl.abort(), 60000);
  res.on('close', () => ctl.abort());
  let up;
  try {
    up = await fetch(url, {
      method: 'POST',
      signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_KEY },
      body: JSON.stringify(upstreamBody)
    });
  } catch {
    clearTimeout(tmo);
    throw httpErr(502, 'Não consegui falar com o serviço de IA. Tenta outra vez.');
  }
  if (!up.ok) {
    clearTimeout(tmo);
    let msg = '';
    try { const j = await up.json(); msg = (j.error && j.error.message) || ''; } catch { /* sem detalhe */ }
    msg = msg.replace(GEMINI_KEY, '[chave]').slice(0, 200);
    if (up.status === 400 || up.status === 429) throw httpErr(up.status, msg || 'Pedido recusado pelo serviço de IA.');
    console.error('Gemini respondeu', up.status);
    throw httpErr(502, 'O serviço de IA recusou o pedido. Tenta outra vez mais tarde.');
  }

  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no' });
  try {
    const reader = up.body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      res.write(value);
    }
  } catch { /* ligação cortada a meio */ }
  finally { clearTimeout(tmo); res.end(); }
}

/* ---------- administração ---------- */
function adminUsers(req, res) {
  requireAdmin(req);
  const rows = db.prepare(`SELECT u.id, u.username, u.email, u.role, u.disabled, u.created_at,
      (SELECT count FROM usage WHERE user_id = u.id AND day = ?) AS today,
      (SELECT length(state) FROM user_state WHERE user_id = u.id) AS state_bytes
    FROM users u ORDER BY u.id`).all(today());
  send(res, 200, {
    users: rows.map(r => ({
      id: r.id, username: r.username, email: r.email, role: r.role,
      disabled: !!r.disabled, created_at: r.created_at,
      today: r.today || 0, state_bytes: r.state_bytes || 0
    }))
  });
}
async function adminSetDisabled(req, res, idStr) {
  const admin = requireAdmin(req);
  const body = await readJson(req);
  const id = Number(idStr);
  if (id === admin.id) throw httpErr(400, 'Não podes desativar a tua própria conta.');
  const target = db.prepare('SELECT id, role FROM users WHERE id = ?').get(id);
  if (!target) throw httpErr(404, 'Utilizador não encontrado.');
  if (target.role === 'admin') throw httpErr(400, 'Não é possível desativar outro administrador por aqui.');
  const disabled = body.disabled === true;
  db.prepare('UPDATE users SET disabled = ? WHERE id = ?').run(disabled ? 1 : 0, id);
  if (disabled) db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
  audit(admin.id, 'set_disabled', id, disabled ? 'desativada' : 'reativada');
  send(res, 200, { ok: true });
}

/* ---------- encaminhamento ---------- */
async function route(req, res, url) {
  const p = url.pathname, m = req.method;
  if (m === 'POST' && p === '/api/auth/register') return register(req, res);
  if (m === 'POST' && p === '/api/auth/login') return login(req, res);
  if (m === 'POST' && p === '/api/auth/logout') return logout(req, res);
  if (m === 'GET' && p === '/api/auth/me') return send(res, 200, { user: publicUser(requireUser(req)) });
  if (m === 'GET' && p === '/api/state') return getState(req, res);
  if (m === 'PUT' && p === '/api/state') return putState(req, res);
  if (m === 'DELETE' && p === '/api/state') return deleteState(req, res);
  if (m === 'POST' && p === '/api/account/delete') return deleteAccount(req, res);
  if (m === 'POST' && p === '/api/gemini/stream') return geminiStream(req, res);
  if (m === 'GET' && p === '/api/admin/users') return adminUsers(req, res);
  const dm = p.match(/^\/api\/admin\/users\/(\d+)\/disabled$/);
  if (m === 'POST' && dm) return adminSetDisabled(req, res, dm[1]);
  throw httpErr(404, 'Caminho não encontrado.');
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json', '.json': 'application/json'
};
function serveStatic(req, res, pathname) {
  let p;
  try { p = decodeURIComponent(pathname); } catch { return sendError(res, 400, 'Caminho inválido.'); }
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, p));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return sendError(res, 404, 'Não encontrado.');
  fs.readFile(file, (err, data) => {
    if (err) return sendError(res, 404, 'Não encontrado.');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  const url = new URL(req.url, 'http://localhost');
  if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url.pathname);
  res.setHeader('Cache-Control', 'no-store');
  try {
    checkOrigin(req);
    await route(req, res, url);
  } catch (err) {
    const status = err instanceof HttpError ? err.status : 500;
    if (status === 500) console.error('Erro interno:', err && err.stack ? err.stack.split('\n').slice(0, 2).join(' | ') : err);
    if (!res.headersSent) sendError(res, status, status === 500 ? 'Erro interno do servidor. Tenta outra vez.' : err.message);
    else res.end();
  }
});

if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`Ali Assistente a correr na porta ${PORT}`);
    if (!GEMINI_KEY) console.log('Aviso: GEMINI_API_KEY não definida. A IA não funciona até a definires.');
  });
}

module.exports = { server, db, hashPassword, verifyPassword, sanitizeState, validateRegister };
